Action()
{

	lr_start_transaction("navigate");

	web_set_sockets_option("SSL_VERSION", "AUTO");

	web_add_auto_header("Accept-Language", 
		"en-US,en;q=0.9");

/*Correlation comment - Do not change!  Original value='DOGS' Name ='c_category' Type ='Manual'*/
	web_reg_save_param_regexp(
		"ParamName=c_category",
		"RegExp=categories/(.*?)\">",
		SEARCH_FILTERS,
		"Scope=Body",
		"IgnoreRedirections=No",
		"RequestUrl=*/jpetstore.aspectran.com/*",
		LAST);

	web_url("jpetstore.aspectran.com", 
		"URL=https://jpetstore.aspectran.com/", 
		"Resource=0", 
		"RecContentType=text/html", 
		"Referer=", 
		"Snapshot=t2.inf", 
		"Mode=HTTP", 
		LAST);

	web_concurrent_start(NULL);

	web_url("logo-topbar.gif", 
		"URL=https://jpetstore.aspectran.com/images/logo-topbar.gif", 
		"Resource=1", 
		"RecContentType=image/gif", 
		"Referer=https://jpetstore.aspectran.com/", 
		"Snapshot=t3.inf", 
		LAST);

	web_url("splash.gif", 
		"URL=https://jpetstore.aspectran.com/images/splash.gif", 
		"Resource=1", 
		"RecContentType=image/gif", 
		"Referer=https://jpetstore.aspectran.com/", 
		"Snapshot=t4.inf", 
		LAST);

	web_url("pets.png", 
		"URL=https://petclinic.aspectran.com/images/pets.png", 
		"Resource=1", 
		"RecContentType=image/png", 
		"Referer=https://jpetstore.aspectran.com/", 
		"Snapshot=t6.inf", 
		LAST);

	web_concurrent_end(NULL);

	lr_end_transaction("navigate",LR_AUTO);

	lr_think_time(45);

	lr_start_transaction("signin");

	web_url("Sign In", 
		"URL=https://jpetstore.aspectran.com/account/signonForm", 
		"Resource=0", 
		"RecContentType=text/html", 
		"Referer=https://jpetstore.aspectran.com/", 
		"Snapshot=t7.inf", 
		"Mode=HTTP", 
		LAST);

	web_submit_data("signon", 
		"Action=https://jpetstore.aspectran.com/account/signon", 
		"Method=POST", 
		"RecContentType=text/html", 
		"Referer=https://jpetstore.aspectran.com/account/signonForm", 
		"Snapshot=t8.inf", 
		"Mode=HTTP", 
		ITEMDATA, 
		"Name=referer", "Value=", ENDITEM, 
		"Name=username", "Value={p_username}", ENDITEM, 
		"Name=password", "Value={p_password}", ENDITEM, 
		LAST);

	lr_end_transaction("signin",LR_AUTO);

	lr_think_time(8);

	lr_start_transaction("category");

	web_url("Dogs",
		"URL=https://jpetstore.aspectran.com/categories/{c_category}",
		"Resource=0",
		"RecContentType=text/html",
		"Referer=https://jpetstore.aspectran.com/",
		"Snapshot=t9.inf",
		"Mode=HTTP",
		LAST);

	lr_end_transaction("category",LR_AUTO);

	lr_think_time(20);

	lr_start_transaction("productid");

/*Correlation comment - Do not change!  Original value='EST-31' Name ='c_item' Type ='Manual'*/
	web_reg_save_param_regexp(
		"ParamName=c_item",
		"RegExp=items/(.*?)\">",
		SEARCH_FILTERS,
		"Scope=Body",
		"IgnoreRedirections=No",
		LAST);

	web_url("K9-PO-02",
		"URL=https://jpetstore.aspectran.com/products/K9-PO-02",
		"Resource=0",
		"RecContentType=text/html",
		"Referer=https://jpetstore.aspectran.com/categories/{c_category}",
		"Snapshot=t10.inf",
		"Mode=HTTP",
		LAST);

	lr_end_transaction("productid",LR_AUTO);

	lr_think_time(22);

	lr_start_transaction("itemid");

	web_url("EST-31",
		"URL=https://jpetstore.aspectran.com/products/K9-PO-02/items/{c_item}",
		"Resource=0",
		"RecContentType=text/html",
		"Referer=https://jpetstore.aspectran.com/products/K9-PO-02",
		"Snapshot=t11.inf",
		"Mode=HTTP",
		LAST);

	web_url("dog6.gif",
		"URL=https://jpetstore.aspectran.com/images/dog6.gif",
		"Resource=1",
		"RecContentType=image/gif",
		"Referer=https://jpetstore.aspectran.com/products/K9-PO-02/items/{c_item}",
		"Snapshot=t12.inf",
		LAST);

	lr_end_transaction("itemid",LR_AUTO);

	lr_start_transaction("Addtocart");

	web_url("Add to Cart",
		"URL=https://jpetstore.aspectran.com/cart/addItemToCart?itemId={c_item}",
		"Resource=0",
		"RecContentType=text/html",
		"Referer=https://jpetstore.aspectran.com/products/K9-PO-02/items/{c_item}",
		"Snapshot=t13.inf",
		"Mode=HTTP",
		LAST);

	lr_end_transaction("Addtocart",LR_AUTO);

	lr_think_time(18);

	lr_start_transaction("checkout");

	web_url("Proceed to Checkout", 
		"URL=https://jpetstore.aspectran.com/order/newOrderForm", 
		"Resource=0", 
		"RecContentType=text/html", 
		"Referer=https://jpetstore.aspectran.com/cart/viewCart", 
		"Snapshot=t14.inf", 
		"Mode=HTTP", 
		LAST);

	lr_end_transaction("checkout",LR_AUTO);

	lr_think_time(24);

	lr_start_transaction("continue");

	web_submit_data("newOrder", 
		"Action=https://jpetstore.aspectran.com/order/newOrder", 
		"Method=POST", 
		"RecContentType=text/html", 
		"Referer=https://jpetstore.aspectran.com/order/newOrderForm", 
		"Snapshot=t15.inf", 
		"Mode=HTTP", 
		ITEMDATA, 
		"Name=paymentForm", "Value=true", ENDITEM, 
		"Name=billingForm", "Value=true", ENDITEM, 
		"Name=cardType", "Value=Visa", ENDITEM, 
		"Name=creditCard", "Value={p_creditcard}", ENDITEM, 
		"Name=expiryDate", "Value=12/2019", ENDITEM, 
		"Name=billToFirstName", "Value=shravani", ENDITEM, 
		"Name=billToLastName", "Value=rajulu", ENDITEM, 
		"Name=billAddress1", "Value=mgroad", ENDITEM, 
		"Name=billAddress2", "Value=royal", ENDITEM, 
		"Name=billCity", "Value=ballari", ENDITEM, 
		"Name=billState", "Value=karnataka", ENDITEM, 
		"Name=billZip", "Value=583101", ENDITEM, 
		"Name=billCountry", "Value=india", ENDITEM, 
		LAST);

	lr_end_transaction("continue",LR_AUTO);

	lr_start_transaction("confirm");

	web_submit_data("submitOrder", 
		"Action=https://jpetstore.aspectran.com/order/submitOrder", 
		"Method=POST", 
		"RecContentType=text/html", 
		"Referer=https://jpetstore.aspectran.com/order/newOrder", 
		"Snapshot=t16.inf", 
		"Mode=HTTP", 
		ITEMDATA, 
		"Name=confirmed", "Value=true", ENDITEM, 
		LAST);

	lr_end_transaction("confirm",LR_AUTO);

	return 0;
}